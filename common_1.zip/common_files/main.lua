-- NX Injector Test Mod
print("NX MOD LOADED OK")
